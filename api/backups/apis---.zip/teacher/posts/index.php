<?php

include_once('../../database.php');

$header = apache_request_headers();

if (($header['Key'] != '78zb89v8czxcz0bcvncvnzc')) {
    echo json_encode(['status' => 'true', 'msg' => 'Invalid Key Provided', 'result' => 'Key Error']);
    die();
}
$errorMsg = array();
$success = array();

if (isset($_GET["action"])) {

    if (($_GET["action"] == 'get_posts')) {
        extract($_POST);

//        $data = json_decode(file_get_contents("php://input"), TRUE);

        $query = "select * from tbl_post where school_id='" . $id . "' and status='active' ORDER BY addedon DESC";
        $run = mysqli_query($db, $query);
        $count = mysqli_num_rows($run);
        if ($count > 0) {
            while ($row = mysqli_fetch_assoc($run)) {
                if($row['author_type']=='Admin'){
                    $image  =   'http://ahadigischools.in/school/uploads/posts/'.$row['image'];
                    $author_name  =   get_particular_name('name', $row['author_id'], 'tbl_school', 'id');
                }else if($row['author_type']=='Teacher'){
                    $image  =   'http://ahadigischools.in/teacher/uploads/posts/'.$row['image'];
                    $author_name  =   get_particular_name('name', $row['author_id'], 'tbl_teacher', 'id');
                }
                
                $arr = array(
                    'id' => $row['id'],
                    'school_id' => $row['school_id'],
                    'author_id' => $row['author_id'],
                    'author_name' => $author_name,
                    'author_type' => $row['author_type'],
                    'title' => $row['title'],
                    'image' => $image,
                    'description' => html_entity_decode($row['description']),
                    'datetime' => $row['datetime'],
                    'addedon' => $row['addedon'],
                    'status' => ucfirst($row['status'])
                );
            }
            echo json_encode(['status' => 'true', 'data' => $arr, 'result' => 'Data Found']);
        } else {
            echo json_encode(['status' => 'true', 'msg' => 'No Post Yet', 'result' => 'Data Not Found']);
        }
    }
    
    if (($_GET["action"] == 'get_post_detail')) {
        extract($_POST);

//        $data = json_decode(file_get_contents("php://input"), TRUE);

        $query = "select * from tbl_post where post_id='" . $id . "'";
        $run = mysqli_query($db, $query);
        $count = mysqli_num_rows($run);
        if ($count > 0) {
            while ($row = mysqli_fetch_assoc($run)) {
                if($row['author_type']=='Admin'){
                    $image  =   'http://ahadigischools.in/school/uploads/posts/'.$row['image'];
                    $author_name  =   get_particular_name('name', $row['author_id'], 'tbl_school', 'id');
                }else if($row['author_type']=='Teacher'){
                    $image  =   'http://ahadigischools.in/teacher/uploads/posts/'.$row['image'];
                    $author_name  =   get_particular_name('name', $row['author_id'], 'tbl_teacher', 'id');
                }
                
                $arr = array(
                    'id' => $row['id'],
                    'school_id' => $row['school_id'],
                    'author_id' => $row['author_id'],
                    'author_name' => $author_name,
                    'author_type' => $row['author_type'],
                    'title' => $row['title'],
                    'image' => $image,
                    'description' => html_entity_decode($row['description']),
                    'datetime' => $row['datetime'],
                    'addedon' => $row['addedon'],
                    'status' => ucfirst($row['status'])
                );
            }
            echo json_encode(['status' => 'true', 'data' => $arr, 'result' => 'Data Found']);
        } else {
            echo json_encode(['status' => 'true', 'msg' => 'No Post Yet', 'result' => 'Data Not Found']);
        }
    }
}
?>
